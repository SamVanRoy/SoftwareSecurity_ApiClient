exports.handler = (event, context, callback) => {
    // TODO implement
    callback(null, 'Dit is de privateGet');
};